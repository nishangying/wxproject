

  ● 布局：以 g 为命名空间，例如：.g-wrap 、.g-header、.g-content。
  ● 状态：以 s 为命名空间，表示动态的、具有交互性质的状态，例如：.s-current、s-selected。
  ● 工具：以 u 为命名空间，表示不耦合业务逻辑的、可复用的的工具，例如：u-clearfix、u-ellipsis。
  ● 组件：以 m 为命名空间，表示可复用、移植的组件模块，例如：m-slider、m-dropMenu。
  ● 钩子：以 j 为命名空间，表示特定给 JavaScript 调用的类名，例如：j-request、j-open。

[](https://www.iconfont.cn/collections/detail?spm=a313x.7781069.1998910419.d9df05512&cid=16957)